# 💿 Program Owner , By : SaherBlueEagle
💿 BlueEagle jRAT V1.0 [Windows RAT / Linux RAT / MAC RAT] 
[Windows RAT] [Linux RAT] [MAC RAT] 
# 💿  Ver 1.6 Updated for potential security issues to save users from reverse connections
# 💿  Ver 1.5 Updated for hacking android , the apk Builder is standlone in zip file provided
# ▶️ NOTE ▶️
▶ Watch the tutorials till the end , because of any question submitted about a point was explained in tutorial , will not be answered 

# Support us please 🥰 for more & more  , Even by a follow 😍, Star 😍, this will be highly appreciated , encourge to release some useful sources 🥰 🥰

# 💿  Ver 1.4 Updated for working on MAC issues , For working on MAC : , choose port 8080 , else will exit due to MAC restrictions for ports usage (OS issue)
# 💿 For working on Linux : open terminal , then change dir to folder release , then "sudo java -jar SBEjRAT.jar" 
# Next Update Show : https://www.facebook.com/watch/?v=443194090003685

<p align="center">
<img src="https://raw.githubusercontent.com/SaherBlueEagle/BlueEagle_jRAT/master/screensj.png" ><br>

</p>
<p align="center">
<img src="https://raw.githubusercontent.com/SaherBlueEagle/BlueEagle_jRAT/master/jRAT%20on%20MAC.png" ><br>

</p>

Facebook : you can easily search facebook using this 3Word Nickname ;) 

this is a cross platform RAT tool (java RAT) / (jRAT) which is { [Windows RAT] [Linux RAT] [MAC RAT] } which is fully programmed in java be a user friendly and easy to use and builds out trojans (.jar) and controls the victims running those trojans on same port at same time ,this tool is fully in java (Client & Server in java) and this tool is now registerd to be free , and on the user responsibility 


# 🏳 This is For Educational Purposes Only ! and User is responsible for his usage of this Tool  🔞

For Example : 
- Parental Control , Track what your children are doing.
- Business Administration , Monitor what employees are doing.
- School/Institutions , for students
- Personal Control and File Backup , Make sure no one is using your computer when you are away.
- Other Noble Purposes
# default logins : admin , admin
# Update : No lag when selecting victim , "About" button was added 
# Controller On Windows OS Tutorial 1  https://www.youtube.com/watch?v=PpJLlgenwaQ
# Controller On MAC OS Tutorial 2 https://www.youtube.com/watch?v=KXEG_LfZ-GI
# 🏳 NOTE : make sure the full program directory not contains "space" to make it able to create itself configuration file
Stay updated with my blog : 
https://blueeaglehacks.blogspot.com/2020/08/blue-eagle-java-rat.html
 
# If you like my work, consider buying me a Nescafe coffee Or Energy Drink 🥰 

# Bitcoin : 3DP2uB5jzxbwVcBm2ssrUstgkdCJPxciWm

[![Bitcoin Donate Button](https://raw.githubusercontent.com/SaherBlueEagle/XPR-2020-Free/master/Bitcoin-Donate-button.png)](https://www.facebook.com/NsBleeD/posts/)
# Support us please 🥰  , Even by a follow 😍, Star 😍 , this will be highly appreciated , encourge to release some useful sources 🥰 🥰
Bitcoin : 3LfLEoLpt3XBz7ozwSSsawWSZJruCQSQgx

[![Patreaon Button](https://raw.githubusercontent.com/SaherBlueEagle/XPR-2020-Free/master/patreon_button2.png)](https://www.patreon.com/BlueEagle)
# Support us please 🥰 for more & more  , Even by a follow 😍, Star 😍, this will be highly appreciated , encourge to release some useful sources 🥰 🥰

[![Facebook Button](https://raw.githubusercontent.com/SaherBlueEagle/XPR-2020-Free/master/facebook_button.png)](https://www.facebook.com/NsBleeD/posts/)
